def get_version():
    return "1.0.0"

__version__ = get_version()